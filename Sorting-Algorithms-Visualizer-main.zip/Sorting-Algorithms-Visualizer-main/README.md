# Sorting-Algorithm-Visualizer
https://sorting-algorithm-visualizer-monk0707.netlify.app
<br />
1.Web app for visualizing different sorting algorithms using HTML, CSS,and Javascript.<br />
2.Implemented Bubble Sort, Insertion Sort, Selection Sort, Merge Sort and Quick Sort and also displayed their time complexities and total run time.
